<?php include('../templates/header.php'); ?>

<?php include('../templates/mailsettings.php'); ?>

<?php include('../templates/footer.php'); ?>