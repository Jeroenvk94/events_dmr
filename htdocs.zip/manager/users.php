<?php include('../templates/header.php'); ?>

<?php include('../templates/users.php'); ?>

<?php include('../templates/footer.php'); ?>