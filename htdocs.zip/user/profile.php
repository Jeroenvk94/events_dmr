<?php include('../templates/header.php'); ?>

<?php include('../templates/userprofile.php'); ?>

<?php include('../templates/footer.php'); ?>