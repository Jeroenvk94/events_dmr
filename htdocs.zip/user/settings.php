<?php include('../templates/header.php'); ?>

<?php include('../templates/usersettings.php'); ?>

<?php include('../templates/footer.php'); ?>