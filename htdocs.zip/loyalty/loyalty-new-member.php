<?php include('../templates/header.php'); ?>

<?php include('../templates/new-member.php'); ?>

<?php include('../templates/footer.php'); ?>