<?php include('../templates/header.php'); ?>

<?php include('../templates/loyalty-members.php'); ?>

<?php include('../templates/footer.php'); ?>