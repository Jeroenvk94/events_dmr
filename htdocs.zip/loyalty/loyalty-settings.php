<?php include('../templates/header.php'); ?>

<?php include('../templates/loyaltysettings.php'); ?>

<?php include('../templates/footer.php'); ?>