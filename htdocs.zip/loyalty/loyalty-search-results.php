<?php include('../templates/header.php'); ?>

<?php include('../templates/loyalty-search.php'); ?>

<?php include('../templates/footer.php'); ?>