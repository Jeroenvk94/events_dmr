<?php include('../templates/header.php'); ?>

<?php include('../templates/tickets-sent.php'); ?>

<?php include('../templates/footer.php'); ?>