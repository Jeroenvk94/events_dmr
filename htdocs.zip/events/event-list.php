<?php include('../templates/header.php'); ?>

<?php include('../templates/event-list.php'); ?>

<?php include('../templates/footer.php'); ?>