<?php include('../templates/header.php'); ?>

<?php include('../templates/view-attendees.php'); ?>

<?php include('../templates/footer.php'); ?>