<?php include('../templates/header.php'); ?>

<?php include('../templates/new-event.php'); ?>

<?php include('../templates/footer.php'); ?>