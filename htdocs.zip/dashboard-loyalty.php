<?php include('templates/header.php'); ?>

<?php include('templates/dashboard-mailchimp.php'); ?>

<?php include('templates/footer.php'); ?>